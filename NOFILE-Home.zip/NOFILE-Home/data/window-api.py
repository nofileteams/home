import os
import tkinter as tk

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULT_TITLE = "test"
DEFAULT_WIDTH = 800
DEFAULT_HEIGHT = 600


def load_title():
    # Load window title from txt/title.txt
    title_path = os.path.join(BASE_DIR, "txt", "title.txt")
    if not os.path.isfile(title_path):
        return DEFAULT_TITLE

    try:
        with open(title_path, "r", encoding="utf-8") as f:
            title = f.read().strip()
        return title if title else DEFAULT_TITLE
    except Exception:
        return DEFAULT_TITLE


def load_size():
    # Load window size from txt/size.txt
    size_path = os.path.join(BASE_DIR, "txt", "size.txt")
    if not os.path.isfile(size_path):
        return DEFAULT_WIDTH, DEFAULT_HEIGHT

    try:
        with open(size_path, "r", encoding="utf-8") as f:
            content = f.read().strip()

        if not content or "x" not in content.lower():
            return DEFAULT_WIDTH, DEFAULT_HEIGHT

        parts = content.lower().split("x")
        if len(parts) != 2:
            return DEFAULT_WIDTH, DEFAULT_HEIGHT

        width = int(parts[0].strip())
        height = int(parts[1].strip())

        if width <= 0 or height <= 0:
            return DEFAULT_WIDTH, DEFAULT_HEIGHT

        return width, height
    except Exception:
        return DEFAULT_WIDTH, DEFAULT_HEIGHT


def set_icon(root):
    # Set window icon if icon.ico exists
    icon_path = os.path.join(BASE_DIR, "icon.ico")
    if not os.path.isfile(icon_path):
        return
    try:
        root.iconbitmap(icon_path)
    except Exception:
        pass


def load_background(frame):
    # Load background color from txt/background.txt
    bg_path = os.path.join(BASE_DIR, "txt", "background.txt")

    if not os.path.isfile(bg_path):
        frame.configure(bg="white")
        return

    try:
        with open(bg_path, "r", encoding="utf-8") as f:
            color = f.read().strip()

        if not color:
            frame.configure(bg="white")
            return

        frame.configure(bg=color)

    except Exception:
        frame.configure(bg="white")


def load_screen(frame, root):
    # Execute screen.txt as Python code
    screen_path = os.path.join(BASE_DIR, "txt", "screen.txt")
    if not os.path.isfile(screen_path):
        return

    try:
        with open(screen_path, "r", encoding="utf-8") as f:
            code = f.read()

        exec_env = {
            "frame": frame,
            "root": root,
            "tk": tk,
            "__builtins__": __builtins__,
        }

        exec(code, exec_env)

    except Exception:
        pass


def main():
    root = tk.Tk()

    root.title(load_title())
    set_icon(root)

    width, height = load_size()
    root.geometry(f"{width}x{height}")

    frame = tk.Frame(root)
    frame.pack(expand=True, fill="both")

    # Apply background color
    load_background(frame)

    load_screen(frame, root)

    root.mainloop()


if __name__ == "__main__":
    main()