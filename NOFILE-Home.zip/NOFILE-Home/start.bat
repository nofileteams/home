@echo off
color B
cd data
python3 window-api.py
exit