cd data
python3 window-api.py
